-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2021 at 04:55 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socical_22`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_emailaddress`
--

CREATE TABLE `account_emailaddress` (
  `id` bigint(20) NOT NULL,
  `email` varchar(254) NOT NULL,
  `verified` tinyint(1) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `account_emailconfirmation`
--

CREATE TABLE `account_emailconfirmation` (
  `id` bigint(20) NOT NULL,
  `created` datetime(6) NOT NULL,
  `sent` datetime(6) DEFAULT NULL,
  `key` varchar(64) NOT NULL,
  `email_address_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add site', 7, 'add_site'),
(26, 'Can change site', 7, 'change_site'),
(27, 'Can delete site', 7, 'delete_site'),
(28, 'Can view site', 7, 'view_site'),
(29, 'Can add email address', 8, 'add_emailaddress'),
(30, 'Can change email address', 8, 'change_emailaddress'),
(31, 'Can delete email address', 8, 'delete_emailaddress'),
(32, 'Can view email address', 8, 'view_emailaddress'),
(33, 'Can add email confirmation', 9, 'add_emailconfirmation'),
(34, 'Can change email confirmation', 9, 'change_emailconfirmation'),
(35, 'Can delete email confirmation', 9, 'delete_emailconfirmation'),
(36, 'Can view email confirmation', 9, 'view_emailconfirmation'),
(37, 'Can add social account', 10, 'add_socialaccount'),
(38, 'Can change social account', 10, 'change_socialaccount'),
(39, 'Can delete social account', 10, 'delete_socialaccount'),
(40, 'Can view social account', 10, 'view_socialaccount'),
(41, 'Can add social application', 11, 'add_socialapp'),
(42, 'Can change social application', 11, 'change_socialapp'),
(43, 'Can delete social application', 11, 'delete_socialapp'),
(44, 'Can view social application', 11, 'view_socialapp'),
(45, 'Can add social application token', 12, 'add_socialtoken'),
(46, 'Can change social application token', 12, 'change_socialtoken'),
(47, 'Can delete social application token', 12, 'delete_socialtoken'),
(48, 'Can view social application token', 12, 'view_socialtoken'),
(49, 'Can add user_profile', 13, 'add_user_profile'),
(50, 'Can change user_profile', 13, 'change_user_profile'),
(51, 'Can delete user_profile', 13, 'delete_user_profile'),
(52, 'Can view user_profile', 13, 'view_user_profile'),
(53, 'Can add share_link', 14, 'add_share_link'),
(54, 'Can change share_link', 14, 'change_share_link'),
(55, 'Can delete share_link', 14, 'delete_share_link'),
(56, 'Can view share_link', 14, 'view_share_link'),
(57, 'Can add share_link_page', 15, 'add_share_link_page'),
(58, 'Can change share_link_page', 15, 'change_share_link_page'),
(59, 'Can delete share_link_page', 15, 'delete_share_link_page'),
(60, 'Can view share_link_page', 15, 'view_share_link_page'),
(61, 'Can add create_share_link', 16, 'add_create_share_link'),
(62, 'Can change create_share_link', 16, 'change_create_share_link'),
(63, 'Can delete create_share_link', 16, 'delete_create_share_link'),
(64, 'Can view create_share_link', 16, 'view_create_share_link');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(8, 'account', 'emailaddress'),
(9, 'account', 'emailconfirmation'),
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session'),
(7, 'sites', 'site'),
(10, 'socialaccount', 'socialaccount'),
(11, 'socialaccount', 'socialapp'),
(12, 'socialaccount', 'socialtoken'),
(16, 'user', 'create_share_link'),
(14, 'user', 'share_link'),
(15, 'user', 'share_link_page'),
(13, 'user', 'user_profile');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2021-10-09 08:05:20.514560'),
(2, 'auth', '0001_initial', '2021-10-09 08:05:21.425285'),
(3, 'account', '0001_initial', '2021-10-09 08:05:21.634739'),
(4, 'account', '0002_email_max_length', '2021-10-09 08:05:21.653894'),
(5, 'account', '0003_auto_20211008_1808', '2021-10-09 08:05:21.967399'),
(6, 'admin', '0001_initial', '2021-10-09 08:05:22.134314'),
(7, 'admin', '0002_logentry_remove_auto_add', '2021-10-09 08:05:22.143292'),
(8, 'admin', '0003_logentry_add_action_flag_choices', '2021-10-09 08:05:22.151759'),
(9, 'contenttypes', '0002_remove_content_type_name', '2021-10-09 08:05:22.282138'),
(10, 'auth', '0002_alter_permission_name_max_length', '2021-10-09 08:05:22.358408'),
(11, 'auth', '0003_alter_user_email_max_length', '2021-10-09 08:05:22.380622'),
(12, 'auth', '0004_alter_user_username_opts', '2021-10-09 08:05:22.389445'),
(13, 'auth', '0005_alter_user_last_login_null', '2021-10-09 08:05:22.458019'),
(14, 'auth', '0006_require_contenttypes_0002', '2021-10-09 08:05:22.463005'),
(15, 'auth', '0007_alter_validators_add_error_messages', '2021-10-09 08:05:22.472978'),
(16, 'auth', '0008_alter_user_username_max_length', '2021-10-09 08:05:22.493922'),
(17, 'auth', '0009_alter_user_last_name_max_length', '2021-10-09 08:05:22.513868'),
(18, 'auth', '0010_alter_group_name_max_length', '2021-10-09 08:05:22.533815'),
(19, 'auth', '0011_update_proxy_permissions', '2021-10-09 08:05:22.547778'),
(20, 'auth', '0012_alter_user_first_name_max_length', '2021-10-09 08:05:22.566727'),
(21, 'sessions', '0001_initial', '2021-10-09 08:05:22.621580'),
(22, 'sites', '0001_initial', '2021-10-09 08:05:22.657484'),
(23, 'sites', '0002_alter_domain_unique', '2021-10-09 08:05:22.681420'),
(24, 'socialaccount', '0001_initial', '2021-10-09 08:05:23.185870'),
(25, 'socialaccount', '0002_token_max_lengths', '2021-10-09 08:05:23.245389'),
(26, 'socialaccount', '0003_extra_data_default_dict', '2021-10-09 08:05:23.259421'),
(27, 'socialaccount', '0004_auto_20211008_1808', '2021-10-09 08:05:23.909024'),
(28, 'user', '0001_initial', '2021-10-09 08:05:24.074599'),
(29, 'user', '0002_alter_user_profile_country', '2021-10-09 08:05:24.400514'),
(30, 'user', '0003_auto_20210922_1051', '2021-10-09 08:05:24.439888'),
(31, 'user', '0004_user_profile_user_app_auth_conect', '2021-10-09 08:05:24.476251'),
(32, 'user', '0005_remove_user_profile_user_app_auth_conect', '2021-10-09 08:05:24.497888'),
(33, 'user', '0006_remove_user_profile_country', '2021-10-09 08:05:24.556233'),
(34, 'user', '0007_delete_country', '2021-10-09 08:05:24.576045'),
(35, 'user', '0008_auto_20210923_1559', '2021-10-09 08:05:24.732164'),
(36, 'user', '0009_alter_user_profile_profile_image', '2021-10-09 08:05:24.790955'),
(37, 'user', '0010_info_social', '2021-10-09 08:05:24.892299'),
(38, 'user', '0011_auto_20210923_1648', '2021-10-09 08:05:24.983201'),
(39, 'user', '0012_delete_info_social', '2021-10-09 08:05:25.001136'),
(40, 'user', '0013_share_link_share_link_page', '2021-10-09 08:05:25.096583'),
(41, 'user', '0014_auto_20211009_1504', '2021-10-09 08:05:25.146512'),
(42, 'user', '0015_share_link_share_link_page', '2021-10-09 08:06:15.867932'),
(43, 'user', '0016_share_link_code_invite', '2021-10-09 09:49:17.832267'),
(44, 'user', '0017_alter_share_link_address', '2021-10-09 10:00:42.794315'),
(45, 'user', '0018_auto_20211009_1702', '2021-10-09 10:03:05.053523'),
(46, 'user', '0013_create_share_link_share_link_share_link_page', '2021-10-12 07:00:54.783320'),
(47, 'user', '0014_alter_create_share_link_link_share', '2021-10-12 08:22:00.579608'),
(48, 'user', '0015_create_share_link_time_share', '2021-10-13 07:04:38.168043'),
(49, 'user', '0016_alter_create_share_link_time_share', '2021-10-13 07:04:57.698553');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('vr7wfwcz07i1fw6pm41f0hz37seyc7n3', 'eyJudW1fdmlzaXRzIjoxfQ:1maWLV:9CMubGfToDs71A6FmeyBXyHso6uSSuTVz8TU7YeUPz0', '2021-10-27 04:58:29.527836');

-- --------------------------------------------------------

--
-- Table structure for table `django_site`
--

CREATE TABLE `django_site` (
  `id` int(11) NOT NULL,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_site`
--

INSERT INTO `django_site` (`id`, `domain`, `name`) VALUES
(2, 'example.com', 'example.com');

-- --------------------------------------------------------

--
-- Table structure for table `socialaccount_socialaccount`
--

CREATE TABLE `socialaccount_socialaccount` (
  `id` bigint(20) NOT NULL,
  `provider` varchar(30) NOT NULL,
  `uid` varchar(191) NOT NULL,
  `last_login` datetime(6) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `extra_data` longtext NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `socialaccount_socialapp`
--

CREATE TABLE `socialaccount_socialapp` (
  `id` bigint(20) NOT NULL,
  `provider` varchar(30) NOT NULL,
  `name` varchar(40) NOT NULL,
  `client_id` varchar(191) NOT NULL,
  `secret` varchar(191) NOT NULL,
  `key` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `socialaccount_socialapp_sites`
--

CREATE TABLE `socialaccount_socialapp_sites` (
  `id` bigint(20) NOT NULL,
  `socialapp_id` bigint(20) NOT NULL,
  `site_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `socialaccount_socialtoken`
--

CREATE TABLE `socialaccount_socialtoken` (
  `id` bigint(20) NOT NULL,
  `token` longtext NOT NULL,
  `token_secret` longtext NOT NULL,
  `expires_at` datetime(6) DEFAULT NULL,
  `account_id` bigint(20) NOT NULL,
  `app_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_create_share_link`
--

CREATE TABLE `user_create_share_link` (
  `id` bigint(20) NOT NULL,
  `code_user` longtext NOT NULL,
  `page_link` longtext NOT NULL,
  `link_share` longtext NOT NULL,
  `count_view_site` int(11) NOT NULL,
  `time_share` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_create_share_link`
--

INSERT INTO `user_create_share_link` (`id`, `code_user`, `page_link`, `link_share`, `count_view_site`, `time_share`) VALUES
(2, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'https://youtube.com/watch?v=1oJaVznp3V8&list=UUyBI6m1CUkd2eQuxxtWPQeg&index=5', '63539a2d44', 16, 10),
(5, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'https://127.0.0.1:8000/en/user/real_link', '9d6f3667ba', 17, 10),
(17, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'gghghghghghghgh', 'ef23b4dfa3', 1, 10),
(18, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'gghghghghghghghghgh', '5f9ac60ec2', 1, 10),
(19, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'dssfsdfsdfsdf', 'f16b95391c', 1, 10),
(20, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'asdasdasdasd', '66194d8458', 1, 10),
(21, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'asdasdasdasdweqwe', '9e23a6b2b7', 1, 10),
(22, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'asdasdasddddd', 'b12562db2f', 1, 10),
(23, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'qweqweqwe', '47e3f7f317', 1, 10),
(24, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'qweqweqweqweqwe', '0ea9f520fa', 1, 10),
(25, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'qweqweqweqweqwewww', 'da81832e0a', 1, 10),
(26, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'qweqweqweqwew', '72acead3f1', 1, 10),
(27, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'asdasdasdasdasd', '27716dbd47', 1, 10),
(28, '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', 'asdasdasd', '3ade420465', 1, 10);

-- --------------------------------------------------------

--
-- Table structure for table `user_share_link`
--

CREATE TABLE `user_share_link` (
  `id` bigint(20) NOT NULL,
  `name` longtext NOT NULL,
  `code` longtext NOT NULL,
  `code_invite` longtext NOT NULL,
  `by_invite` longtext NOT NULL,
  `address` longtext NOT NULL,
  `phone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_share_link`
--

INSERT INTO `user_share_link` (`id`, `name`, `code`, `code_invite`, `by_invite`, `address`, `phone`) VALUES
(1, 'Tien Van Pham', '715742287cf827156974ac7aab43ac8cfe874d9fa777a84b23410632ee5e', '9825c6e61c97b83e00ba', '', 'Ha noi, Hai Phong', '0969938801'),
(2, 'Dat Nguyen', '8ac02fed8ce776fa09a7162221c24122b3a5ac2c9434b391ac007f28a27a', '9dd8e0d47a06d4fd4262', '', '75 Cau Giay st.', '0969938801');

-- --------------------------------------------------------

--
-- Table structure for table `user_share_link_page`
--

CREATE TABLE `user_share_link_page` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `code` longtext NOT NULL,
  `page_link` longtext NOT NULL,
  `count_view_site` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_user_profile`
--

CREATE TABLE `user_user_profile` (
  `id` bigint(20) NOT NULL,
  `address` longtext NOT NULL,
  `phone` varchar(50) NOT NULL,
  `profile_user_id` int(11) DEFAULT NULL,
  `profile_image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_emailaddress`
--
ALTER TABLE `account_emailaddress`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `account_emailaddress_user_id_2c513194_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `account_emailconfirmation`
--
ALTER TABLE `account_emailconfirmation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`),
  ADD KEY `account_emailconfirmation_email_address_id_5b7f8c58_fk` (`email_address_id`);

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `django_site`
--
ALTER TABLE `django_site`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_site_domain_a2e37b91_uniq` (`domain`);

--
-- Indexes for table `socialaccount_socialaccount`
--
ALTER TABLE `socialaccount_socialaccount`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `socialaccount_socialaccount_provider_uid_fc810c6e_uniq` (`provider`,`uid`),
  ADD KEY `socialaccount_socialaccount_user_id_8146e70c_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `socialaccount_socialapp`
--
ALTER TABLE `socialaccount_socialapp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `socialaccount_socialapp_sites`
--
ALTER TABLE `socialaccount_socialapp_sites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `socialaccount_socialapp_sites_socialapp_id_site_id_71a9a768_uniq` (`socialapp_id`,`site_id`),
  ADD KEY `socialaccount_socialapp_sites_site_id_2579dee5_fk_django_site_id` (`site_id`);

--
-- Indexes for table `socialaccount_socialtoken`
--
ALTER TABLE `socialaccount_socialtoken`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq` (`app_id`,`account_id`),
  ADD KEY `socialaccount_socialtoken_account_id_951f210e_fk` (`account_id`);

--
-- Indexes for table `user_create_share_link`
--
ALTER TABLE `user_create_share_link`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_create_share_link_link_share_5c169475_uniq` (`link_share`) USING HASH;

--
-- Indexes for table `user_share_link`
--
ALTER TABLE `user_share_link`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`) USING HASH,
  ADD UNIQUE KEY `code_invite` (`code_invite`) USING HASH;

--
-- Indexes for table `user_share_link_page`
--
ALTER TABLE `user_share_link_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_user_profile`
--
ALTER TABLE `user_user_profile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`profile_user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_emailaddress`
--
ALTER TABLE `account_emailaddress`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `account_emailconfirmation`
--
ALTER TABLE `account_emailconfirmation`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `django_site`
--
ALTER TABLE `django_site`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `socialaccount_socialaccount`
--
ALTER TABLE `socialaccount_socialaccount`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `socialaccount_socialapp`
--
ALTER TABLE `socialaccount_socialapp`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `socialaccount_socialapp_sites`
--
ALTER TABLE `socialaccount_socialapp_sites`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `socialaccount_socialtoken`
--
ALTER TABLE `socialaccount_socialtoken`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_create_share_link`
--
ALTER TABLE `user_create_share_link`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `user_share_link`
--
ALTER TABLE `user_share_link`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_share_link_page`
--
ALTER TABLE `user_share_link_page`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_user_profile`
--
ALTER TABLE `user_user_profile`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account_emailaddress`
--
ALTER TABLE `account_emailaddress`
  ADD CONSTRAINT `account_emailaddress_user_id_2c513194_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `account_emailconfirmation`
--
ALTER TABLE `account_emailconfirmation`
  ADD CONSTRAINT `account_emailconfirmation_email_address_id_5b7f8c58_fk` FOREIGN KEY (`email_address_id`) REFERENCES `account_emailaddress` (`id`);

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `socialaccount_socialaccount`
--
ALTER TABLE `socialaccount_socialaccount`
  ADD CONSTRAINT `socialaccount_socialaccount_user_id_8146e70c_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `socialaccount_socialapp_sites`
--
ALTER TABLE `socialaccount_socialapp_sites`
  ADD CONSTRAINT `socialaccount_socialapp_sites_site_id_2579dee5_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`);

--
-- Constraints for table `socialaccount_socialtoken`
--
ALTER TABLE `socialaccount_socialtoken`
  ADD CONSTRAINT `socialaccount_socialtoken_account_id_951f210e_fk` FOREIGN KEY (`account_id`) REFERENCES `socialaccount_socialaccount` (`id`),
  ADD CONSTRAINT `socialaccount_socialtoken_app_id_636a42d7_fk` FOREIGN KEY (`app_id`) REFERENCES `socialaccount_socialapp` (`id`);

--
-- Constraints for table `user_user_profile`
--
ALTER TABLE `user_user_profile`
  ADD CONSTRAINT `user_user_profile_profile_user_id_ef70f326_fk_auth_user_id` FOREIGN KEY (`profile_user_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
